﻿public enum Direction
{
  Horizontal,
  Vertical
}